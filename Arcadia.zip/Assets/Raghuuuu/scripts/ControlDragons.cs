using System.Collections;
using UnityEngine;

public class ControlDragons : MonoBehaviour
{
    [SerializeField] GameObject Dragon;
    private Vector3 position;
    private float startX = -11f;
    private float targetX = 11f;

    void Start()
    {
        // Start generating dragons
        StartCoroutine(WaitBeforeGenerating());
    }

    void generate(bool right)
    { 
        GameObject obj = Instantiate(Dragon, position, Quaternion.identity);
        obj.transform.parent = this.transform;
        
        DragonScript childScript = obj.GetComponent<DragonScript>();
        if (childScript != null)
        {
            childScript.startScript(right);
        }
    }

    private IEnumerator WaitBeforeGenerating()
    {
        int count = 7;
        while (count >= 0)
        {
            yield return new WaitForSeconds(2.5f);
            float randY = Random.Range(0.5f, 4f);
            bool right = Random.Range(0f,1f) > 0.5f;
            if (right)
            {
                position = new Vector3(startX, randY, 0);
            }
            else
            {
                position = new Vector3(targetX, randY, 0);

            }

            generate(right);
            count--;
        }
    }
}
