using UnityEngine;

public class Projectile : MonoBehaviour
{
    public float speed = 5f;
    public float lifespan = 3f;

    private Vector3 direction;

    public void Initialize(Vector3 fireDirection)
    {
        direction = fireDirection;
        Destroy(gameObject, lifespan);
    }

    void Update()
    {
        transform.position += direction * speed * Time.deltaTime;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (!collision.CompareTag("Dragon"))
        {
            Destroy(gameObject,0);
            Debug.Log("Hello world");
        }
        
    }
}
