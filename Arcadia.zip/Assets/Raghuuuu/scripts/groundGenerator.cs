using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class groundGenerator : MonoBehaviour
{
    [SerializeField] int width,height;
    [SerializeField] GameObject dirt,grass;
    [SerializeField] GameObject trunkPrefab, leafPrefab;
    [SerializeField] GameObject tiles,floor;

    public float treeHeight = 1.4f; // Number of trunk levels
    public float trunkHeight = 0.2f; // Height of each trunk piece
    public int widthPerLevel = 2;

    // Start is called before the first frame update
    void Start()
    {
        Generate();
        //GenerateTree(new Vector3(0,-2f,0));
    }

    void Generate()
    {
        float minLength = 2.5f;
        float maxLength = 3.0f;
        float wavelength = Random.Range(minLength, maxLength);
        float minHeight = 0.3f;
        float maxHeight = 0.5f;
        float amplitude = Random.Range(minHeight, maxHeight);
        float ct = Random.Range(0f, 1.5f);
        //float ct = -4f;
        float treeX = Random.Range(-8.1f, -4.1f);
        treeX =  Mathf.Round(treeX * 10f) / 10f;
        float homeX = Random.Range(6.1f, 3.1f);
        homeX = Mathf.Round(homeX * 10f) / 10f;

        for (float i = -width; i < width; i += 0.1f)
        {
            
            float x = ct * 0.2f;
            float y = Mathf.Sin(x/wavelength) * amplitude - 3.6f ;
            for(float j = -height; j < y; j += 0.2f)
            {
                SpawnObj(dirt,i, j);
            }
            SpawnObj(grass, i, y);
            if (Mathf.Abs(treeX - i) < 0.01f)
            {
                Vector3 treePosition = new Vector3(treeX, y-0.05f, 0);
                GenerateTree(treePosition);
            }
            if (Mathf.Abs(homeX - i) < 0.01f)
            {
                Vector3 homePosition = new Vector3(homeX, y-0.2f, 0);
                GenerateHome(homePosition);
            }
            
            //ct += 1;
            ct += Random.Range(0.3f, 1.5f);
            wavelength += Random.Range(0f,0.01f);
        }
    }
    void GenerateHome(Vector2 position)
    {
        Vector2 newPosition = position;
        for(int i = 0; i <= 12; i++)
        {
            if(i % 3 == 0)
            {
                for(int j = 0; j < 3; j++)
                {
                    Vector2 vector2 = newPosition + new Vector2(j*0.7f - 0.1f,-0.025f);
                    //SpawnObj(floor, i, j);
                    GameObject obj = Instantiate(floor, vector2, Quaternion.identity);
                    obj.transform.parent = this.transform;
                }
                newPosition += new Vector2(0, 0.2f);
            }
            else
            {
                for (int j = 0; j < 3; j++)
                {
                    Vector2 vector2 = newPosition + new Vector2(j * 0.6f, 0);
                    //SpawnObj(floor, i, j);
                    GameObject obj = Instantiate(tiles, vector2, Quaternion.identity);
                    obj.transform.parent = this.transform;
                }
                newPosition += new Vector2(0, 0.27f);
            }

        }
    }
    void SpawnObj(GameObject obj, float x, float y)
    {
        obj = Instantiate(obj, new Vector2(x, y), Quaternion.identity);
        obj.transform.parent = this.transform;
    }
    void GenerateTree( Vector3 position)
    {
        Vector3 currentPosition = position;

        for (float i = 0; i < 9; i++)
        {
            Vector3 newPosition = currentPosition + new Vector3(0,i * 0.2f,0);
            for(float j=-0.3f;j<= 0.3f;j += 0.2f)
            {
                Vector3 newtPosition = newPosition + new Vector3(j, 0, 0);
                GameObject trunkPiece = Instantiate(trunkPrefab, newtPosition, Quaternion.identity);
                trunkPiece.transform.SetParent(this.transform);
                
            }

            //currentPosition += new Vector3(0, trunkHeight, 0);
        }
        currentPosition += new Vector3(0, 1.7f, 0);
        anotherTree(currentPosition);
    }

    void anotherTree(Vector3 position) //Set layers for different objects
    {
        float r = 1.4f;
        Vector3 temp = position - new Vector3(r * Mathf.Sin(0.6283f), 0, 0);
        float X = temp.x;
        float Y = temp.y;
        float radius = 0.7f;
        GenerateLeaves(X,Y,radius);
        
        temp = position + new Vector3(r * Mathf.Sin(0.7283f), 0.2f, 0);
        X = temp.x;
        Y = temp.y;
        radius = 0.8f;
        GenerateLeaves(X, Y, radius);
        //r = 1.6f;
        temp = position + new Vector3(-2f * Mathf.Sin(0.6283f), r*Mathf.Cos(0.6283f), 0);
        X = temp.x;
        Y = temp.y;
        radius = 0.8f;
        GenerateLeaves(X, Y, radius);
        temp = position + new Vector3(1.6f * Mathf.Sin(0.7283f), r * Mathf.Cos(0.6283f), 0);
        X = temp.x;
        Y = temp.y;
        radius = 0.8f;
        GenerateLeaves(X, Y, radius);
        temp = position + new Vector3(0, 0.7f * Mathf.Cos(0.2142f), 0);
        X = temp.x;
        Y = temp.y;
        radius = 0.8f;
        GenerateLeaves(X, Y, radius);
        r = 1.6f;
        temp = position + new Vector3(0, r * Mathf.Cos(0.2142f), 0);
        X = temp.x;
        Y = temp.y;
        radius = 1.1f;
        GenerateLeaves(X, Y, radius);

    }
    void GenerateLeaves(float X, float Y, float radius)
    {
        for (float x = X - radius; x <= X + radius; x += 0.05f)
        {
            for (float y = Y - radius; y <= Y + radius; y += 0.05f)
            {
                float z = (X - x) * (X - x) + (Y - y) * (Y - y);
                if (z + 0.06f <= radius * radius)
                {
                    GameObject leaf = Instantiate(leafPrefab, new Vector3(x, y, 0), Quaternion.identity);
                    leaf.transform.SetParent(this.transform);
                }
            }
        }
    }
}
