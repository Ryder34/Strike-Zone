using System.Collections;
using UnityEngine;

public class DragonScript : MonoBehaviour
{
    //[SerializeField] Sprite[] sprites;
    //[SerializeField] GameObject dragon;
    private int spriteIndex;
    //private SpriteRenderer spriteRenderer;
    [SerializeField] GameObject projectilePrefab;
    public float fireIntervalMin = 4f; // Minimum time between shots
    public float fireIntervalMax = 12f; // Maximum time between shots
    private float nextFireTime;

    private Transform playerTransform;

    private float moveSpeed = 1.3f;
    private float targetX = 11f;
    private float startX = -11f; 
    private bool isMovingRight = true;
    private bool isMoving = false;
    private float minY = 0.7f;
    private float maxY = 4.5f;
    private Vector3 targetPosition;

    void Start()
    {
        //myFunction();
        //SetNewTargetPosition();
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
        ScheduleNextFire();
    }

    private void Awake()
    {
        //spriteRenderer = GetComponent<SpriteRenderer>();
    }
    /*
    void myFunction()
    {
        InvokeRepeating(nameof(AnimateSprite), 0.15f, 0.15f);
    }*/

    void Update()
    {
        if (isMoving)
        {
            MoveDragon();
        }
        
    }

    void ScheduleNextFire()
    {
        nextFireTime = Time.time + Random.Range(fireIntervalMin, fireIntervalMax);
    }

    public void startScript(bool movingR)
    {
        //Debug.Log("hello");
        isMovingRight = movingR;
        SetNewTargetPosition();
        isMoving = true;

    }

    void MoveDragon()
    {
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
        //if (playerTransform == null) return;

        Vector3 targetPosition1 = playerTransform.position;
        Vector3 fireDirection = (targetPosition1 - transform.position).normalized;

        if (Time.time >= nextFireTime && ((isMovingRight && fireDirection.x > 0) || (!isMovingRight && fireDirection.x < 0)))
        {
            GameObject projectile = Instantiate(projectilePrefab, transform.position, Quaternion.identity);
            projectile.GetComponent<Projectile>().Initialize(fireDirection);
            ScheduleNextFire();
        }

       /* if (transform.position.x <= -3f + 0.01f && transform.position.x >= -3f - 0.01f)
        {
            
            //return; // Exit the method to prevent further movement
            //moveSpeed = 0.5f;
            StartCoroutine(PauseAtPosition());
            //moveSpeed = 1.3f;

            //Debug.Log("Hello World!");
            return;
        }*/

        if (Vector3.Distance(transform.position, targetPosition) < 0.5f)
        {
            isMovingRight = !isMovingRight;
            SetNewTargetPosition();
            //FlipSprites();
            if (!isMovingRight)
            {
                FlipSprites();
            }
            StartCoroutine(WaitBeforeMoving());
        }
    }

    private IEnumerator PauseAtPosition()
    {
        float originalSpeed = moveSpeed;
        moveSpeed = 0.8f;

        yield return new WaitForSeconds(1f);

        moveSpeed = originalSpeed;
    }
    private IEnumerator WaitBeforeMoving()
    {
        isMoving = false;
        yield return new WaitForSeconds(1f);
        isMoving = true;
    }

    private void SetNewTargetPosition()
    {
        float targetPositionX = isMovingRight ? targetX : startX;
        if (isMovingRight)
        {
            FlipSprites();
        }
        float randomY = Random.Range(minY, maxY);
        targetPosition = new Vector3(targetPositionX, randomY, 0);
    }
    public void FlipSprites()
    {
        
        Vector3 scale = transform.localScale;
        scale.x *= -1;
        transform.localScale = scale;
    }
    /*
    private void AnimateSprite()
    {
        spriteIndex++;
        if (spriteIndex >= sprites.Length)
        {
            spriteIndex = 0;
        }
        spriteRenderer.sprite = sprites[spriteIndex];
    }*/
}
