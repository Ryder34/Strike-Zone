using Unity.VisualScripting;
using UnityEngine;
public class move : MonoBehaviour
{

    [SerializeField] private float speed;

    private Rigidbody2D enemybody;
    private Animator enemyanim;
    private bool enemygrounded;

    private void Awake()
    {
        //to get the components into the code
        enemybody = GetComponent<Rigidbody2D>();
        enemyanim = GetComponent<Animator>();
    }
    private void Update()
    {
        if(enemybody.rotation!=0) enemybody.rotation = 0;
        //float horizontalInput = Input.GetAxis("Horizontal");
        //body.velocity = new Vector2(Input.GetAxis("Horizontal") * speed, body.velocity.y);
        //flip
        //if (horizontalInput > 0.01f)
        //    transform.localScale = new Vector2(1, 1);
        //else if (horizontalInput < -0.01f)
        //    transform.localScale = new Vector2(-1, 1);
        //jump
        //if (Input.GetKey(KeyCode.Space) && grounded)
        //{
        //    body.velocity = new Vector2(body.velocity.x, speed * 1.5f);
        //    grounded = false;
        //}
        //set animations
        //anim.SetBool("run", horizontalInput != 0); //run and idle
        enemyanim.SetBool("grounded", enemygrounded);

    }

    private void OnCollision2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "ground")
            enemygrounded = true;
    }

}