using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class health : MonoBehaviour
{

    public float Health;
    public float currenthealth;
    private Animator enemyanim;
    private Rigidbody2D enemybody;

    private void Start()
    {
        enemybody = GetComponent<Rigidbody2D>();
        enemyanim = GetComponent<Animator>();
        currenthealth = Health;
    }
    void Update()
    {
        if(Health < currenthealth)
        {
            currenthealth = Health;
            enemyanim.SetTrigger("attacked");
        }

        if(Health <= 0)
        {
            enemyanim.SetBool("dead",true);
            Destroy(enemybody.gameObject,1);
        }
    }
}
