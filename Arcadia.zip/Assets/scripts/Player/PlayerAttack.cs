using UnityEngine;

public class attack : MonoBehaviour
{
    [SerializeField] private float attackcooldown;
    private Animator anim;
    private Movement playerMovement;
    private float cooldowntimer = Mathf.Infinity;
    public GameObject attackpoint;
    public float radius;
    public LayerMask enemies;
    public float damage = 10;
    private void Awake()
    {
        //to get the components into the code
        playerMovement = GetComponent<Movement>();
        anim = GetComponent<Animator>();
    }

    private void Update()
    {
        //attack
        if (Input.GetKey(KeyCode.X) && cooldowntimer > attackcooldown)
        {
            anim.SetTrigger("attack");
            cooldowntimer = 0;
        }

        cooldowntimer += Time.deltaTime; //increments for every frame
    }

    private void attackframe()
    {
        Collider2D[] enemy = Physics2D.OverlapCircleAll(attackpoint.transform.position, radius, enemies);

        //to hit all enemies within the attack circle
        foreach (Collider2D enemyGameObject in enemy) 
        {
            Debug.Log("hit");
            enemyGameObject.GetComponent<health>().Health -= damage;
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(attackpoint.transform.position, radius);
    }
}
