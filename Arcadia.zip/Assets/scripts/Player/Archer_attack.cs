using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Archer_attack : MonoBehaviour
{
    public weapon Weapon;
    private Animator anim;
    private void Awake()
    {
        anim = GetComponent<Animator>();
    }
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Weapon.fire();
            anim.SetTrigger("attack");
        }
    }

    //private void attackframe()
    //{
    //    Collider2D[] enemy = Physics2D.OverlapCircleAll(attackpoint.transform.position, radius, enemies);

    //    //to hit all enemies within the attack circle
    //    foreach (Collider2D enemyGameObject in enemy)
    //    {
    //        Debug.Log("hit");
    //        enemyGameObject.GetComponent<health>().Health -= damage;
    //    }
    //}
}
