using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shift : MonoBehaviour
{
    public GameObject swordman, archer;

    int whichAvatarOn = 1;
    void Start()
    {
        swordman.gameObject.SetActive(true);
        archer.gameObject.SetActive(false);
    }

    private void Update()
    {
        if (archer.transform.rotation != Quaternion.identity) 
        {
            archer.transform.rotation = Quaternion.identity;
        }
        if (Input.GetKeyDown(KeyCode.Z))
        {
            if (whichAvatarOn == 1) { whichAvatarOn = 0; }
            else {  whichAvatarOn = 1; }
            switchAvatar();
        }
    }
    public void switchAvatar()
    {
        
        switch (whichAvatarOn)
        {
            case 0:
                //whichAvatarOn = 0;
                Vector2 position= swordman.transform.position;
                swordman.gameObject.SetActive(false);
                archer.transform.position = position;
                archer.gameObject.SetActive(true);
                break;
            case 1:
                //whichAvatarOn = 1;
                Vector2 position1 = archer.transform.position;
                archer.gameObject.SetActive(false);
                swordman.transform.position= position1;
                swordman.gameObject.SetActive(true);
                break;
        }
    }
}
