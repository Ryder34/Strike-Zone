using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class weapon : MonoBehaviour
{
    private Vector2 mousePosition;
    public Camera scenecamera;
    public GameObject bullet;
    public Transform firePoint;
    public float fireforce;
    public Transform parentTransform;
    public Vector3 offset; // Optional: Set an offset from the parent
    private Rigidbody2D body;
    private void Awake()
    {
        //to get the components into the code
        body = GetComponent<Rigidbody2D>();
    }
    public void fire()
    {
        GameObject projectile = Instantiate(bullet, firePoint.position,firePoint.rotation);
        projectile.GetComponent<Rigidbody2D>().AddForce(firePoint.up * fireforce, ForceMode2D.Impulse);
    }

    public void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");

        ////mouse position and hit


        ////flip
        //if (horizontalInput > 0.01f)
        //    transform.localScale = new Vector2(1, 1);
        //else if (horizontalInput < -0.01f)
        //    transform.localScale = new Vector2(-1, 1);
        mousePosition = scenecamera.ScreenToWorldPoint(Input.mousePosition);
        if (mousePosition.x < parentTransform.position.x  && horizontalInput == 0f) {
            parentTransform.localScale = new Vector2(-1, 1);
        }
        else if(mousePosition.x > parentTransform.position.x && horizontalInput == 0f) parentTransform.localScale = new Vector2(1, 1);
        Vector2 aimDirection = mousePosition - body.position;
        float aimAngle = Mathf.Atan2(aimDirection.y, aimDirection.x) * Mathf.Rad2Deg - 90f;
        if (parentTransform != null)
        {
            // Make the child follow the parent's position, plus any desired offset
            transform.position = parentTransform.position + offset;
        }
        body.rotation = aimAngle;
    }
}
